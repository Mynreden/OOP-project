public interface Comparable<Person>{


}
