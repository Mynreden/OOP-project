public interface Payable {
    public double getPaymentAmount();

}
